import { PublicKey } from "@solana/web3.js";
export declare const DELEGATION_PROGRAM_ID: PublicKey;
export declare const MAGIC_PROGRAM_ID: PublicKey;
export declare const MAGIC_CONTEXT_ID: PublicKey;
export declare const PERMISSION_PROGRAM_ID: PublicKey;
//# sourceMappingURL=constants.d.ts.map